
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` VALUES (5,'Capstone','brands/imSFp0zVHPfg0BcNNe1UV51rkVK4xZQpzYLHs5A0.png','2024-11-26 12:11:14','2024-11-26 12:11:14'),(7,'Brand 2','brands/25SZzgVsEoRvBvOjnwLUMwqeSiUDpNxQbsHEwHba.png','2024-11-29 12:57:53','2024-11-29 12:57:53'),(8,'CAPS','brands/sJZC7UeJKWiSEUEjgZMKIXYH8PGJjRPMLSJRqiNp.png','2024-12-17 21:01:13','2024-12-17 21:01:13'),(9,'KSKSK','brands/QgL0748yDJyTHnBqQdcgt1iIimlOqCZukWqroWOC.png','2024-12-17 21:01:35','2024-12-17 21:01:35'),(10,'Adidas','brands/EJjP2ehMWXx3fmOFERePRskQBoVQjC5CmZnzifsf.png','2024-12-17 21:01:47','2024-12-17 21:01:47'),(11,'Nike','brands/GYo8p4lEg2462KNvokgBlmSaMelBUj3R25ypLD85.jpg','2024-12-17 21:02:11','2024-12-17 21:02:11');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES ('spatie.permission.cache','a:3:{s:5:\"alias\";a:0:{}s:11:\"permissions\";a:0:{}s:5:\"roles\";a:0:{}}',1735220051);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_brand_id_foreign` (`brand_id`),
  CONSTRAINT `categories_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (4,'Hoodies',NULL,5,'2024-11-26 12:11:21','2024-11-26 12:11:21'),(6,'Category two',NULL,7,'2024-11-29 12:58:08','2024-11-29 12:58:08'),(7,'SKSKSK',NULL,10,'2024-12-17 21:02:42','2024-12-17 21:02:42');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `color_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `color_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `color_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `color_item_item_id_color_id_unique` (`item_id`,`color_id`),
  KEY `color_item_color_id_foreign` (`color_id`),
  CONSTRAINT `color_item_color_id_foreign` FOREIGN KEY (`color_id`) REFERENCES `colors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `color_item_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `color_item` WRITE;
/*!40000 ALTER TABLE `color_item` DISABLE KEYS */;
INSERT INTO `color_item` VALUES (1,92,1,NULL,NULL),(2,93,1,NULL,NULL),(3,94,1,NULL,NULL),(4,96,1,NULL,NULL),(5,97,1,NULL,NULL),(6,98,1,NULL,NULL),(7,99,1,NULL,NULL),(8,100,1,NULL,NULL),(9,101,1,NULL,NULL),(10,102,1,NULL,NULL),(11,103,1,NULL,NULL),(12,104,1,NULL,NULL),(13,105,1,NULL,NULL),(14,106,1,NULL,NULL),(15,107,1,NULL,NULL),(16,108,1,NULL,NULL),(17,109,1,NULL,NULL),(18,110,1,NULL,NULL),(19,111,1,NULL,NULL),(20,112,1,NULL,NULL),(21,113,2,NULL,NULL),(22,114,1,NULL,NULL),(23,115,2,NULL,NULL),(24,116,1,NULL,NULL),(25,117,2,NULL,NULL),(26,118,1,NULL,NULL),(27,119,1,NULL,NULL),(28,120,1,NULL,NULL),(29,121,1,NULL,NULL),(30,122,2,NULL,NULL),(31,123,2,NULL,NULL),(32,124,2,NULL,NULL),(33,125,2,NULL,NULL),(34,126,1,NULL,NULL),(35,127,1,NULL,NULL),(36,128,1,NULL,NULL),(37,129,1,NULL,NULL),(38,130,1,NULL,NULL),(39,131,2,NULL,NULL),(40,132,2,NULL,NULL),(41,133,2,NULL,NULL),(42,134,2,NULL,NULL),(43,135,2,NULL,NULL);
/*!40000 ALTER TABLE `color_item` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colors` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hex_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (1,'Red',NULL,'2024-12-22 08:32:06','2024-12-22 08:32:06'),(2,'Blue',NULL,'2024-12-25 10:08:21','2024-12-25 10:08:21');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `item_size`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `item_size` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned NOT NULL,
  `size_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `item_size_item_id_foreign` (`item_id`),
  KEY `item_size_size_id_foreign` (`size_id`),
  CONSTRAINT `item_size_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `item_size_size_id_foreign` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `item_size` WRITE;
/*!40000 ALTER TABLE `item_size` DISABLE KEYS */;
INSERT INTO `item_size` VALUES (28,63,1,NULL,NULL),(29,63,2,NULL,NULL),(30,63,3,NULL,NULL),(31,64,5,NULL,NULL),(39,67,1,NULL,NULL),(40,67,2,NULL,NULL),(41,67,3,NULL,NULL),(42,68,1,NULL,NULL),(43,68,2,NULL,NULL),(44,68,3,NULL,NULL),(45,69,7,NULL,NULL),(46,70,2,NULL,NULL),(47,70,3,NULL,NULL),(48,70,5,NULL,NULL),(49,71,2,NULL,NULL),(50,71,3,NULL,NULL),(51,71,5,NULL,NULL),(52,72,1,NULL,NULL),(53,72,5,NULL,NULL),(54,73,1,NULL,NULL),(55,73,2,NULL,NULL),(56,73,3,NULL,NULL),(57,74,1,NULL,NULL),(58,74,2,NULL,NULL),(59,74,3,NULL,NULL),(60,75,1,NULL,NULL),(61,75,2,NULL,NULL),(62,75,3,NULL,NULL),(63,76,1,NULL,NULL),(64,76,4,NULL,NULL),(65,77,1,NULL,NULL),(66,77,2,NULL,NULL),(77,83,1,NULL,NULL),(78,83,2,NULL,NULL),(83,86,1,NULL,NULL),(84,86,3,NULL,NULL),(85,87,1,NULL,NULL),(86,87,2,NULL,NULL),(87,88,1,NULL,NULL),(88,88,2,NULL,NULL),(89,89,1,NULL,NULL),(90,89,2,NULL,NULL),(91,90,1,NULL,NULL),(92,90,2,NULL,NULL),(93,91,1,NULL,NULL),(94,91,2,NULL,NULL),(95,92,1,NULL,NULL),(96,92,2,NULL,NULL),(97,93,1,NULL,NULL),(98,93,2,NULL,NULL),(99,94,1,NULL,NULL),(100,94,2,NULL,NULL),(101,96,3,NULL,NULL),(102,97,4,NULL,NULL),(103,98,1,NULL,NULL),(104,98,2,NULL,NULL),(105,99,3,NULL,NULL),(106,100,1,NULL,NULL),(107,101,1,NULL,NULL),(108,102,1,NULL,NULL),(109,102,2,NULL,NULL),(110,103,1,NULL,NULL),(111,103,2,NULL,NULL),(112,104,1,NULL,NULL),(113,104,3,NULL,NULL),(114,104,5,NULL,NULL),(115,105,1,NULL,NULL),(116,106,2,NULL,NULL),(117,107,1,NULL,NULL),(118,108,2,NULL,NULL),(119,109,3,NULL,NULL),(120,110,4,NULL,NULL),(121,111,5,NULL,NULL),(122,112,1,NULL,NULL),(123,113,1,NULL,NULL),(124,114,2,NULL,NULL),(125,115,2,NULL,NULL),(126,116,3,NULL,NULL),(127,117,3,NULL,NULL),(128,118,1,NULL,NULL),(129,119,2,NULL,NULL),(130,120,3,NULL,NULL),(131,121,4,NULL,NULL),(132,122,1,NULL,NULL),(133,123,2,NULL,NULL),(134,124,3,NULL,NULL),(135,125,4,NULL,NULL),(136,126,1,NULL,NULL),(137,127,2,NULL,NULL),(138,128,3,NULL,NULL),(139,129,4,NULL,NULL),(140,130,5,NULL,NULL),(141,131,1,NULL,NULL),(142,132,2,NULL,NULL),(143,133,3,NULL,NULL),(144,134,4,NULL,NULL),(145,135,5,NULL,NULL);
/*!40000 ALTER TABLE `item_size` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint(20) unsigned DEFAULT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  `brand_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `barcode` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `buying_price` decimal(8,2) DEFAULT NULL,
  `selling_price` decimal(8,2) DEFAULT NULL,
  `picture` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax` decimal(8,2) DEFAULT NULL,
  `applied_sale` decimal(8,2) DEFAULT NULL,
  `discount_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'percentage',
  `discount_value` decimal(8,2) NOT NULL DEFAULT 0.00,
  `barcodes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`barcodes`)),
  PRIMARY KEY (`id`),
  KEY `items_parent_id_foreign` (`parent_id`),
  CONSTRAINT `items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (63,NULL,4,5,'Widefit hoodie','2024-11-26 12:11:43','2024-12-18 11:45:02','barcodes/00005463.png','00005463',126,100.00,500.00,NULL,NULL,20.00,'percentage',0.00,NULL),(64,NULL,4,5,'Aiii','2024-11-26 12:55:06','2024-12-24 11:33:35','barcodes/00005464.png','00005464',50,200.00,1000.00,NULL,NULL,20.00,'percentage',0.00,NULL),(67,NULL,6,7,'Item Two','2024-11-29 12:58:34','2024-12-15 09:41:14','barcodes/00007667.png','00007667',1,100.00,200.00,NULL,NULL,10.00,'percentage',0.00,NULL),(68,NULL,4,5,'lala','2024-12-15 10:15:20','2024-12-18 11:31:28','barcodes/00005468.png','00005468',0,200.00,900.00,NULL,0.00,0.00,'percentage',0.00,NULL),(69,NULL,6,5,'Shoe one','2024-12-16 10:30:23','2024-12-18 09:29:53','barcodes/00005669.png','00005669',9,100.00,2000.00,NULL,0.00,0.00,'percentage',0.00,NULL),(70,NULL,6,7,'Nan','2024-12-17 20:57:32','2024-12-18 11:31:28',NULL,NULL,99,99.00,999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(71,NULL,6,7,'Nan','2024-12-17 20:57:58','2024-12-17 20:57:58','barcodes/768.png','768',100,99.00,999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(72,NULL,6,7,'TOOO','2024-12-17 20:59:26','2024-12-22 11:07:08','barcodes/00007672.png','00007672',915,5.00,999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(73,NULL,7,11,'KAKAK','2024-12-17 21:03:16','2024-12-17 21:10:05','barcodes/00011773.png','00011773',97,3.00,33.00,NULL,0.00,0.00,'percentage',0.00,NULL),(74,NULL,7,11,'LKO','2024-12-17 21:03:56','2024-12-23 10:26:17','barcodes/0000011774.png','0000011774',995,99.00,999.00,NULL,0.00,9.00,'percentage',0.00,NULL),(75,NULL,7,11,'OP','2024-12-17 21:06:08','2024-12-22 21:52:27','barcodes/1010111775.png','1010111775',120,100.00,200.00,NULL,NULL,12.00,'percentage',10.00,NULL),(76,NULL,7,11,'NX','2024-12-17 21:07:11','2024-12-23 10:37:58','barcodes/1177600000.png','1177600000',9990,9.00,8888.00,NULL,0.00,8.00,'percentage',0.00,NULL),(77,NULL,7,11,'AX','2024-12-17 21:30:47','2024-12-18 11:48:39','barcodes/1107000077.png','1107000077',28,2.00,10.00,NULL,0.00,2.00,'percentage',0.00,NULL),(83,NULL,7,11,'HOl','2024-12-17 21:42:32','2024-12-23 10:39:47','barcodes/0110070083.png','0110070083',13,1.00,5.00,NULL,0.00,0.00,'percentage',0.00,NULL),(86,NULL,7,11,'Kas','2024-12-17 21:48:10','2024-12-18 09:30:30','barcodes/0110070086.png','0110070086',1,1.00,11.00,NULL,0.00,0.00,'percentage',0.00,NULL),(87,NULL,7,11,'Xaa','2024-12-18 09:20:18','2024-12-25 13:00:07','barcodes/0110070087.png','0110070087',85,4.00,900.00,NULL,0.00,0.00,'percentage',0.00,NULL),(88,NULL,7,11,'LetsTry','2024-12-18 12:10:01','2024-12-23 09:27:54','barcodes/0110070088.png','0110070088',196,900.00,9000.00,NULL,NULL,0.00,'fixed',20.00,NULL),(89,NULL,6,5,'LALALALALAL','2024-12-22 08:25:28','2024-12-23 15:40:57','barcodes/0050060089.png','0050060089',28,100.00,200.00,NULL,NULL,0.00,'percentage',20.00,NULL),(90,NULL,6,9,'vex','2024-12-22 08:34:37','2024-12-22 08:34:37',NULL,NULL,999,100.00,200.00,NULL,0.00,0.00,'percentage',0.00,NULL),(91,NULL,6,9,'vex','2024-12-22 08:35:38','2024-12-23 10:40:04',NULL,NULL,999,100.00,200.00,NULL,0.00,0.00,'percentage',0.00,NULL),(92,NULL,6,9,'vex','2024-12-22 08:38:09','2024-12-22 08:38:09','barcodes/0090060092.png','0090060092',999,100.00,200.00,NULL,0.00,0.00,'percentage',0.00,NULL),(93,NULL,7,11,'NoItem','2024-12-22 10:03:07','2024-12-22 22:53:45','barcodes/0110070093.png','0110070093',298,300.00,3000.00,NULL,0.00,0.00,'percentage',0.00,NULL),(94,NULL,7,11,'Notanitem','2024-12-22 10:06:13','2024-12-22 22:53:45','barcodes/0110070094.png','0110070094',982,100.00,1000.00,NULL,0.00,0.00,'percentage',0.00,NULL),(95,NULL,7,11,'Ls','2024-12-22 10:15:43','2024-12-22 10:15:43',NULL,NULL,0,300.00,3999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(96,NULL,7,11,'Ls - 3 - 1','2024-12-22 10:15:43','2024-12-22 10:15:43',NULL,NULL,0,300.00,3999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(97,NULL,7,11,'Ls - 4 - 1','2024-12-22 10:15:43','2024-12-22 10:15:43',NULL,NULL,0,300.00,3999.00,NULL,0.00,0.00,'percentage',0.00,NULL),(98,NULL,7,11,'Parent','2024-12-22 10:18:41','2024-12-22 22:02:42','barcodes/0110070098.png','0110070098',295,99.00,900.00,NULL,NULL,0.00,'fixed',9.00,NULL),(99,NULL,7,11,'M','2024-12-22 10:21:06','2024-12-22 11:17:54','barcodes/0110070099.png','0110070099',87,98.00,988.00,NULL,0.00,0.00,'percentage',0.00,NULL),(100,NULL,7,11,'Create','2024-12-22 10:26:41','2024-12-24 21:13:44','barcodes/0110070100.png','0110070100',293,300.00,3000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(101,NULL,7,11,'Create2','2024-12-22 10:30:31','2024-12-25 15:59:37','barcodes/0110070101.png','0110070101',279,300.00,3000.00,NULL,0.00,NULL,'fixed',300.00,NULL),(102,NULL,7,11,'ColorSize Item','2024-12-23 11:19:55','2024-12-23 11:19:55',NULL,NULL,100,100.00,10000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(103,NULL,7,5,'ColorSize Item2','2024-12-23 11:22:32','2024-12-24 11:34:17',NULL,NULL,98,100.00,2000.00,NULL,0.00,NULL,'percentage',0.00,'[\"barcodes\\/00500701030101.png\",\"barcodes\\/00500701030201.png\"]'),(104,NULL,6,8,'NotItemSizeColor','2024-12-23 11:34:27','2024-12-24 21:11:03','barcodes/0080060104.png','0080060104',98,10.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(105,NULL,7,11,'Item Try - Red - xs','2024-12-24 12:10:01','2024-12-24 21:16:08','barcodes/0110070105.png','0110070105',97,10.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(106,NULL,7,11,'Item Try - Red - s','2024-12-24 12:10:01','2024-12-24 12:10:01','barcodes/0110070106.png','0110070106',99,10.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(107,NULL,7,11,'Omar Item - Red - xs','2024-12-24 15:30:53','2024-12-25 10:13:55','barcodes/0110070107.png','0110070107',7,100.00,1000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(108,NULL,7,11,'Omar Item - Red - s','2024-12-24 15:30:53','2024-12-25 15:51:22','barcodes/0110070108.png','0110070108',1,100.00,1000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(109,NULL,7,11,'Omar Item - Red - m','2024-12-24 15:30:53','2024-12-25 13:00:07','barcodes/0110070109.png','0110070109',7,100.00,1000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(110,NULL,7,11,'Omar Item - Red - l','2024-12-24 15:30:53','2024-12-24 15:34:02','barcodes/0110070110.png','0110070110',9,100.00,1000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(111,NULL,7,11,'Omar Item - Red - xl','2024-12-24 15:30:53','2024-12-25 15:59:37','barcodes/0110070111.png','0110070111',7,100.00,1000.00,NULL,0.00,NULL,'percentage',0.00,NULL),(112,NULL,6,8,'Item - Red - xs','2024-12-25 10:08:58','2024-12-25 10:08:58','barcodes/0080060112.png','0080060112',99,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(113,NULL,6,8,'Item - Blue - xs','2024-12-25 10:08:58','2024-12-25 10:08:58','barcodes/0080060113.png','0080060113',99,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(114,NULL,6,8,'Item - Red - s','2024-12-25 10:08:58','2024-12-25 10:08:58','barcodes/0080060114.png','0080060114',99,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(115,NULL,6,8,'Item - Blue - s','2024-12-25 10:08:58','2024-12-25 10:08:58','barcodes/0080060115.png','0080060115',99,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(116,NULL,6,8,'Item - Red - m','2024-12-25 10:08:58','2024-12-25 10:08:58','barcodes/0080060116.png','0080060116',99,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(117,NULL,6,8,'Item - Blue - m','2024-12-25 10:08:58','2024-12-25 15:12:25','barcodes/0080060117.png','0080060117',98,9.00,999.00,NULL,0.00,NULL,'percentage',0.00,NULL),(118,NULL,6,9,'Kill - Red - xs','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060118.png','0090060118',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(119,NULL,6,9,'Kill - Red - s','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060119.png','0090060119',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(120,NULL,6,9,'Kill - Red - m','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060120.png','0090060120',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(121,NULL,6,9,'Kill - Red - l','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060121.png','0090060121',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(122,NULL,6,9,'Kill - Blue - xs','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060122.png','0090060122',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(123,NULL,6,9,'Kill - Blue - s','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060123.png','0090060123',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(124,NULL,6,9,'Kill - Blue - m','2024-12-25 10:10:18','2024-12-25 15:07:38','barcodes/0090060124.png','0090060124',98,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(125,NULL,6,9,'Kill - Blue - l','2024-12-25 10:10:18','2024-12-25 10:10:18','barcodes/0090060125.png','0090060125',100,1.00,100.00,NULL,0.00,NULL,'percentage',0.00,NULL),(126,NULL,7,5,'Nour - Red - xs','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070126.png','0050070126',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(127,NULL,7,5,'Nour - Red - s','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070127.png','0050070127',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(128,NULL,7,5,'Nour - Red - m','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070128.png','0050070128',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(129,NULL,7,5,'Nour - Red - l','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070129.png','0050070129',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(130,NULL,7,5,'Nour - Red - xl','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070130.png','0050070130',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(131,NULL,7,5,'Nour - Blue - xs','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070131.png','0050070131',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(132,NULL,7,5,'Nour - Blue - s','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070132.png','0050070132',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(133,NULL,7,5,'Nour - Blue - m','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070133.png','0050070133',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(134,NULL,7,5,'Nour - Blue - l','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070134.png','0050070134',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL),(135,NULL,7,5,'Nour - Blue - xl','2024-12-25 16:21:57','2024-12-25 16:21:57','barcodes/0050070135.png','0050070135',99,10.00,1000.00,NULL,0.00,NULL,'fixed',9.00,NULL);
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2024_09_27_130153_create_items_table',2),(5,'2024_09_27_130153_create_sale_items_table',2),(6,'2024_09_27_130153_create_sales_table',2),(34,'2024_09_27_131748_create_brands_table',3),(35,'2024_09_27_131757_create_categories_table',3),(36,'2024_09_27_141005_add_category_id_to_items_table',3),(37,'2024_09_27_141611_add_brand_id_to_items_table',3),(38,'2024_09_27_151256_add_total_amount_to_sales_table',3),(39,'2024_09_28_071410_add_barcode_to_items_table',4),(40,'2024_09_28_140736_add_code_to_items_table',4),(41,'2024_09_28_143042_drop_code_from_items_table',4),(42,'2024_09_28_155850_add_quantity_to_items_table',4),(43,'2024_09_28_160919_add_item_id_to_sales_table',4),(44,'2024_11_25_134643_create_sizes_table',5),(45,'2024_11_25_135509_add_picture_to_items_table',6),(46,'2024_11_25_135908_create_item_size_table',7),(47,'2024_11_27_121311_create_refunds_table',8),(48,'2024_11_27_213752_create_permission_tables',9),(49,'2024_11_28_174041_add_refunded_quantity_to_sale_items',10),(50,'2024_12_15_003631_create_cash_drawers_table',11),(51,'2024_12_15_003653_create_cash_drawers_table',12),(52,'2024_12_16_172029_add_refund_status_to_sales_table',13),(53,'2024_12_16_180523_add_customer_fields_to_sales_table',14),(54,'2024_12_17_231127_create_colors_table',15),(55,'2024_12_17_231508_create_color_item_table',16),(56,'2024_12_17_233736_add_foreign_keys_to_color_item_table',17),(57,'2024_12_17_234159_create_color_item_table',18),(58,'2024_12_18_135701_add_discount_type_to_items_table',19),(59,'2024_12_18_141507_add_discount_value_to_items_table',20),(60,'2024_12_20_151021_create_colors_table',21),(61,'2024_12_22_103547_create_color_item_table',22),(62,'2024_12_22_115540_add_parent_id_to_items_table',23),(63,'2024_12_23_011454_adding_preferences_column_to_users_table',24),(64,'2024_12_23_132054_add_barcodes_to_items_table',25);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\Models\\User',1),(1,'App\\Models\\User',3),(1,'App\\Models\\User',13),(2,'App\\Models\\User',2),(3,'App\\Models\\User',6);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `refunds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refunds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity_refunded` int(11) NOT NULL,
  `refund_amount` decimal(10,2) NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `refunds_sale_id_foreign` (`sale_id`),
  KEY `refunds_item_id_foreign` (`item_id`),
  CONSTRAINT `refunds_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `refunds_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `refunds` WRITE;
/*!40000 ALTER TABLE `refunds` DISABLE KEYS */;
INSERT INTO `refunds` VALUES (49,392,101,1,2700.00,NULL,'2024-12-24 11:36:47','2024-12-24 11:36:47'),(50,392,100,1,3000.00,NULL,'2024-12-24 11:38:01','2024-12-24 11:38:01'),(51,394,110,1,1000.00,NULL,'2024-12-24 15:34:02','2024-12-24 15:34:02'),(52,395,107,1,1000.00,NULL,'2024-12-24 15:34:59','2024-12-24 15:34:59'),(53,397,107,1,1000.00,NULL,'2024-12-25 10:13:55','2024-12-25 10:13:55');
/*!40000 ALTER TABLE `refunds` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','web','2024-11-28 09:24:23','2024-11-28 09:24:23'),(2,'moderator','web','2024-11-28 09:24:23','2024-11-28 09:24:23'),(3,'cashier','web','2024-11-28 10:07:45','2024-11-28 10:07:45');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sale_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sale_id` bigint(20) unsigned NOT NULL,
  `item_id` bigint(20) unsigned NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `refunded_quantity` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `sale_items_sale_id_foreign` (`sale_id`),
  KEY `sale_items_item_id_foreign` (`item_id`),
  CONSTRAINT `sale_items_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sale_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=294 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sale_items` WRITE;
/*!40000 ALTER TABLE `sale_items` DISABLE KEYS */;
INSERT INTO `sale_items` VALUES (259,393,100,1,3000.00,'2024-12-24 11:56:06','2024-12-24 11:56:06',0),(262,395,111,1,1000.00,'2024-12-24 15:34:53','2024-12-24 15:34:53',0),(263,396,108,3,1000.00,'2024-12-24 15:49:10','2024-12-24 15:49:10',0),(265,398,108,1,1000.00,'2024-12-24 21:09:40','2024-12-24 21:09:40',0),(266,399,107,1,1000.00,'2024-12-24 21:10:19','2024-12-24 21:10:19',0),(267,400,109,1,1000.00,'2024-12-24 21:10:42','2024-12-24 21:10:42',0),(268,401,104,1,100.00,'2024-12-24 21:11:03','2024-12-24 21:11:03',0),(269,402,100,1,3000.00,'2024-12-24 21:13:44','2024-12-24 21:13:44',0),(270,403,87,1,900.00,'2024-12-24 21:14:14','2024-12-24 21:14:14',0),(271,404,105,1,100.00,'2024-12-24 21:15:49','2024-12-24 21:15:49',0),(272,405,105,1,100.00,'2024-12-24 21:16:08','2024-12-24 21:16:08',0),(273,406,107,1,1000.00,'2024-12-24 21:16:25','2024-12-24 21:16:25',0),(274,407,109,1,1000.00,'2024-12-25 13:00:07','2024-12-25 13:00:07',0),(275,407,87,1,900.00,'2024-12-25 13:00:07','2024-12-25 13:00:07',0),(276,407,101,1,2700.00,'2024-12-25 13:00:07','2024-12-25 13:00:07',0),(277,408,124,1,100.00,'2024-12-25 15:05:59','2024-12-25 15:05:59',0),(278,409,124,1,100.00,'2024-12-25 15:07:38','2024-12-25 15:07:38',0),(279,410,117,1,999.00,'2024-12-25 15:12:25','2024-12-25 15:12:25',0),(280,412,108,1,1000.00,'2024-12-25 15:32:23','2024-12-25 15:32:23',0),(281,413,101,1,2700.00,'2024-12-25 15:33:14','2024-12-25 15:33:14',0),(282,414,101,1,2700.00,'2024-12-25 15:36:11','2024-12-25 15:36:11',0),(283,415,101,1,2700.00,'2024-12-25 15:45:57','2024-12-25 15:45:57',0),(284,416,108,1,1000.00,'2024-12-25 15:48:13','2024-12-25 15:48:13',0),(285,416,101,1,2700.00,'2024-12-25 15:48:13','2024-12-25 15:48:13',0),(286,417,108,1,1000.00,'2024-12-25 15:49:52','2024-12-25 15:49:52',0),(287,417,101,2,2700.00,'2024-12-25 15:49:52','2024-12-25 15:49:52',0),(288,418,108,1,1000.00,'2024-12-25 15:51:22','2024-12-25 15:51:22',0),(289,418,101,2,2700.00,'2024-12-25 15:51:22','2024-12-25 15:51:22',0),(290,419,101,2,2700.00,'2024-12-25 15:53:02','2024-12-25 15:53:02',0),(291,420,101,2,2700.00,'2024-12-25 15:56:01','2024-12-25 15:56:01',0),(292,421,101,2,2700.00,'2024-12-25 15:59:37','2024-12-25 15:59:37',0),(293,421,111,1,1000.00,'2024-12-25 15:59:37','2024-12-25 15:59:37',0);
/*!40000 ALTER TABLE `sale_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` bigint(20) unsigned DEFAULT NULL,
  `total_amount` decimal(8,2) NOT NULL,
  `refund_status` enum('no_refund','partial_refund','full_refund') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no_refund',
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` enum('percentage','fixed','none') COLLATE utf8mb4_unicode_ci NOT NULL,
  `discount_value` decimal(10,2) DEFAULT NULL,
  `payment_method` enum('cash','credit_card','paypal','bank_transfer') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `user_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sales_item_id_foreign` (`item_id`),
  CONSTRAINT `sales_item_id_foreign` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=422 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES (392,NULL,-100.00,'full_refund','2024-12-24 13:36:40','2024-12-24 11:36:40','2024-12-24 11:38:01',NULL,NULL,'fixed',100.00,'cash',5700.00,100.00,1),(393,NULL,3000.00,'no_refund','2024-12-24 13:56:06','2024-12-24 11:56:06','2024-12-24 11:56:06',NULL,NULL,'none',0.00,'cash',3000.00,0.00,1),(394,NULL,0.00,'full_refund','2024-12-24 17:32:55','2024-12-24 15:32:55','2024-12-24 15:34:02',NULL,NULL,'fixed',0.00,'cash',1000.00,0.00,1),(395,NULL,960.00,'partial_refund','2024-12-24 17:34:53','2024-12-24 15:34:53','2024-12-24 15:34:59',NULL,NULL,'percentage',2.00,'credit_card',2000.00,40.00,1),(396,NULL,3000.00,'no_refund','2024-12-24 17:49:10','2024-12-24 15:49:10','2024-12-24 15:49:10',NULL,NULL,'none',0.00,'cash',3000.00,0.00,1),(397,NULL,0.00,'full_refund','2024-12-24 19:33:08','2024-12-24 17:33:08','2024-12-25 10:13:55',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(398,NULL,1000.00,'no_refund','2024-12-24 23:09:40','2024-12-24 21:09:40','2024-12-24 21:09:40',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(399,NULL,1000.00,'no_refund','2024-12-24 23:10:19','2024-12-24 21:10:19','2024-12-24 21:10:19',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(400,NULL,1000.00,'no_refund','2024-12-24 23:10:42','2024-12-24 21:10:42','2024-12-24 21:10:42',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(401,NULL,100.00,'no_refund','2024-12-24 23:11:03','2024-12-24 21:11:03','2024-12-24 21:11:03',NULL,NULL,'none',0.00,'cash',100.00,0.00,1),(402,NULL,3000.00,'no_refund','2024-12-24 23:13:44','2024-12-24 21:13:44','2024-12-24 21:13:44',NULL,NULL,'none',0.00,'cash',3000.00,0.00,1),(403,NULL,900.00,'no_refund','2024-12-24 23:14:14','2024-12-24 21:14:14','2024-12-24 21:14:14',NULL,NULL,'none',0.00,'cash',900.00,0.00,1),(404,NULL,100.00,'no_refund','2024-12-24 23:15:49','2024-12-24 21:15:49','2024-12-24 21:15:49',NULL,NULL,'none',0.00,'cash',100.00,0.00,1),(405,NULL,100.00,'no_refund','2024-12-24 23:16:08','2024-12-24 21:16:08','2024-12-24 21:16:08',NULL,NULL,'none',0.00,'cash',100.00,0.00,1),(406,NULL,1000.00,'no_refund','2024-12-24 23:16:25','2024-12-24 21:16:25','2024-12-24 21:16:25',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(407,NULL,4600.00,'no_refund','2024-12-25 15:00:07','2024-12-25 13:00:07','2024-12-25 13:00:07',NULL,NULL,'percentage',0.00,'cash',4600.00,0.00,1),(408,NULL,90.00,'no_refund','2024-12-25 17:05:59','2024-12-25 15:05:59','2024-12-25 15:05:59',NULL,NULL,'fixed',10.00,'cash',100.00,10.00,1),(409,NULL,90.00,'no_refund','2024-12-25 17:07:38','2024-12-25 15:07:38','2024-12-25 15:07:38',NULL,NULL,'fixed',10.00,'cash',100.00,10.00,1),(410,NULL,799.20,'no_refund','2024-12-25 17:12:25','2024-12-25 15:12:25','2024-12-25 15:12:25',NULL,NULL,'percentage',20.00,'cash',999.00,199.80,1),(411,NULL,15300.00,'no_refund','2024-12-25 17:31:19','2024-12-25 15:31:19','2024-12-25 15:31:19',NULL,NULL,'percentage',10.00,'cash',17000.00,0.00,1),(412,NULL,1000.00,'no_refund','2024-12-25 17:32:23','2024-12-25 15:32:23','2024-12-25 15:32:23',NULL,NULL,'none',0.00,'cash',1000.00,0.00,1),(413,NULL,2700.00,'no_refund','2024-12-25 17:33:14','2024-12-25 15:33:14','2024-12-25 15:33:14',NULL,NULL,'none',0.00,'cash',2700.00,0.00,1),(414,NULL,2700.00,'no_refund','2024-12-25 17:36:11','2024-12-25 15:36:11','2024-12-25 15:36:11',NULL,NULL,'none',0.00,'cash',2700.00,0.00,1),(415,NULL,2700.00,'no_refund','2024-12-25 17:45:57','2024-12-25 15:45:57','2024-12-25 15:45:57',NULL,NULL,'none',0.00,'cash',2700.00,0.00,1),(416,NULL,3700.00,'no_refund','2024-12-25 17:48:13','2024-12-25 15:48:13','2024-12-25 15:48:13',NULL,NULL,'none',0.00,'cash',3700.00,0.00,1),(417,NULL,6400.00,'no_refund','2024-12-25 17:49:52','2024-12-25 15:49:52','2024-12-25 15:49:52',NULL,NULL,'none',0.00,'cash',6400.00,0.00,1),(418,NULL,6400.00,'no_refund','2024-12-25 17:51:22','2024-12-25 15:51:22','2024-12-25 15:51:22',NULL,NULL,'none',0.00,'cash',6400.00,0.00,1),(419,NULL,5400.00,'no_refund','2024-12-25 17:53:02','2024-12-25 15:53:02','2024-12-25 15:53:02',NULL,NULL,'none',0.00,'cash',5400.00,0.00,1),(420,NULL,5390.00,'no_refund','2024-12-25 17:56:01','2024-12-25 15:56:01','2024-12-25 15:56:01',NULL,NULL,'fixed',10.00,'cash',5400.00,10.00,1),(421,NULL,5760.00,'no_refund','2024-12-25 17:59:37','2024-12-25 15:59:37','2024-12-25 15:59:37',NULL,NULL,'percentage',10.00,'cash',6400.00,640.00,1);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('CjzdG0V0SMm9m240XNyRIFYGwoAOIlzGxnf6tkq5',1,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:132.0) Gecko/20100101 Firefox/132.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoiZkVpTE12S2hiUUNLS3A1ekIzRG00Zks5Ykt5ejVTWUdFYXJkU2pOSCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9kYXNoYm9hcmQiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=',1734536801),('xKBDFx2i2W1JivkEkLwkwQhYZYEK40OIEbnR73Hy',6,'127.0.0.1','Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:132.0) Gecko/20100101 Firefox/132.0','YTo0OntzOjY6Il90b2tlbiI7czo0MDoib1RNdUZDT3NyN3NsQnNmRzExWXN5ZTBueTEwSlZkUmtFd0FKNkpOVCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9zYWxlcy9jcmVhdGUiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo2O30=',1734564337);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sizes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sizes` WRITE;
/*!40000 ALTER TABLE `sizes` DISABLE KEYS */;
INSERT INTO `sizes` VALUES (1,'xs','clothes','2024-11-25 11:47:49','2024-11-25 11:47:49'),(2,'s','clothes','2024-11-25 12:09:45','2024-11-25 12:09:45'),(3,'m','clothes','2024-11-25 12:09:51','2024-11-25 12:09:51'),(4,'l','clothes','2024-11-25 12:09:56','2024-11-25 12:09:56'),(5,'xl','clothes','2024-11-25 12:10:00','2024-11-25 12:10:00'),(6,'40','shoes','2024-11-25 16:15:40','2024-11-25 16:15:40'),(7,'41','shoes','2024-11-25 16:15:49','2024-11-25 16:15:49');
/*!40000 ALTER TABLE `sizes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'lara_admin','lara_admin@admin.com',NULL,'$2y$12$7V6udZJpN4rMfwFnvtluf.xqTBLzw1A1vNP3emhcwS8TApB10kFr6',NULL,'2024-09-27 10:34:05','2024-09-27 10:34:05'),(2,'Maher Admin','madmin@lhub.com',NULL,'$2y$12$zqgL/xtP8IaAVZCC2JVtEuRYwgaZOLDwcZ.4XAT2KEXQwUuqhYnd6',NULL,'2024-11-22 11:37:23','2024-11-22 11:37:23'),(3,'admin@localhub.com','admin@localhub.com',NULL,'$2y$12$juCVm4SiVKvuVKcYlaAVju.sOeMvLcm5ECxI6Z6ehn3At/8SILR66',NULL,'2024-11-22 11:39:23','2024-11-22 11:39:23'),(6,'Non1','non1@lhub.com',NULL,'$2y$12$VfKakXMLcBRl9FEfRQIqBeawT6Dws5oHciysCx0dyTA18mEW7AZTC',NULL,'2024-12-14 22:08:38','2024-12-14 22:08:38'),(13,'Omar Meneeem','omar_meneeem@admin.lhub',NULL,'$2y$12$EHzzCqIgSzmEs8LjOP1GleedxrzdzgzVCJdmhPlqooeD7cLZ2i5K2',NULL,'2024-12-24 15:35:59','2024-12-24 15:35:59');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

